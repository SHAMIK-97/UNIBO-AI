import os
import time
from minizinc import Instance, Model, Solver
from pathlib import Path
from datetime import timedelta


exec_time = []

print("provide model path: ")
model_path = input()
print("specify solver: ")
solver = input()
solver = solver.lower()
vlsi_Cp = Model(Path(model_path))
chuffed = Solver.lookup(solver)

instance = Instance(chuffed, vlsi_Cp)
print("specify instance folder path: ")
instance_path = input()
instance_path = instance_path + "/ins-"
H = 0
for i in range(1,41):


    result_x = []
    result_y = []
    rot = []
    h = []


    instance_path.join(str(i) + ".txt")
    buf = open(instance_path)
    W = int(buf.readline())
    number_of_blocks = int(buf.readline())

    width = []
    height = []

    for line in buf:
        tmp = line.split()
        tmp = [int(x) for x in tmp]
        width.append(tmp[0])
        height.append(tmp[1])

    instance["W"] = W
    instance["N"] = number_of_blocks
    instance["width"] = width
    instance["height"] = height


    start_time = time.time()

    result = instance.solve(timeout=timedelta(seconds=20),intermediate_solutions=True)
    execution_time = (time.time() - start_time)*1000
    exec_time.append(float('{:.2f}'.format(execution_time)))

    for e in range(len(result)):
        result_x.append(result[e, "x_coordinate"])
        result_y.append(result[e, "y_coordinate"])
        h.append(result[e, "objective"])
        rot.append(result[e, "rotation"])

    if len(h) ==0:
        time.sleep(5)
    if len(h)>0:
        H = min(h)

    if H>0 and len(result_x)>0 and len(result_y)>0 :
        parent_dir = "C:/"
        directory = "OUTPUT"
        path = os.path.join(parent_dir, directory)
        if not os.path.exists(path):
            os.mkdir(path)
        out_file = path + '/out-{}.txt'.format(i)
        out_buf = open(out_file, 'w')
        out_buf.write(str(W) + ' ' + str(H) + '\n')
        out_buf.write(str(number_of_blocks) + '\n')

        for (w, h, cx, cy) in zip(width, height, result_x, result_y):
            out_buf.write(str(w) + ' ' + str(h) + ' ' + str(cx) + ' ' + str(cy) + '\n')
        out_buf.write(str(rot))


out_file = 'Timing.txt'
out_buf = open(out_file, 'w')
out_buf.write(exec_time)
