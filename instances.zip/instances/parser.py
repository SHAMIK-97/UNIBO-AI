import argparse
import os


def removen(str):
    return str.replace("\n", "")
def remove_doubles(l):
    return list(dict.fromkeys(l))

def parse_file(input, output, width, n, dx, dy, short=True):
    output.write(width+"="+removen(input.readline())+";\n")
    output.write(n+"="+removen(input.readline())+";\n")
    line = input.readline()
    print("-", line)
    line=line.split(" ")
    dxl = [line[0]]
    dyl = [line[1].replace("\n","")]
    while True:
        line = input.readline()
        if line == "":
            break
        line = line.split()
        dxl.append(line[0])
        dyl.append(line[1])
    n = len(dxl)

    dxl1 = []
    dyl1 = []
    for l in sorted([(dxl[i],dyl[i]) for i in range(n)], key=lambda k: -int(k[0])*int(k[1])):
        dxl1.append(l[0])
        dyl1.append(l[1])
    dxl=dxl1
    dyl=dyl1
    output.write(dx+"=["+",".join(dxl)+"];\n")
    output.write(dy+"=["+",".join(dyl)+"];\n")
    if  short:
        return

    output.write("dim=[")
    for i in range(n):
        output.write("|\n"+dxl[i]+","+dyl[i])
    output.write("|];\n")

    
    rect_size = remove_doubles([ (dxl[i],dyl[i]) for i in range(n)])
    rect_size = remove_doubles(rect_size + remove_doubles([ (dyl[i],dxl[i]) for i in range(n)]))
    shape_indexes = { i:k+1 for k,i in enumerate(rect_size)}
    valid_shapes = [remove_doubles([shape_indexes[(dxl[i], dyl[i])] if j == 0 else shape_indexes[(dyl[i], dxl[i])] for j in range(2)]) for i in range(n)]

    output.write("nRectangles = " + str(len(rect_size))+";\n")
    output.write("rect_size = [")
    for r in rect_size:
        output.write("|\n"+",".join(r))
    output.write("|];\n")
    output.write("rect_offset = [")
    for r in rect_size:
        output.write("|\n0,0")
    output.write("|];\n")
    output.write("shape = [")
    for s in range(len(rect_size)-1):
        output.write("{" + str(s+1) + "},")
    output.write("{" + str(len(rect_size)) + "}];\n")
    output.write("valid_shapes = [" + ",".join(["{"+",".join([str(s) for s in i])+"}" for i in valid_shapes]) + "];\n")



if __name__ == '__main__':

    parser = argparse.ArgumentParser(
        description='Parse txt file into dzn(Zeynep Kiziltan format)')
    parser.add_argument('-a', '--all', dest='all', action='store_true',
                        help='Convert all txt file in this folder?')
    parser.add_argument('files', metavar='N', type=str, nargs='*',
                        help='List of file to convert')

    parser.add_argument('-w', '--width', dest='width', default='width',
                        help='Used name for width')
    parser.add_argument('-n', '--number', dest='n', default='n',
                        help='Used name for number of chips')
    parser.add_argument('-x', '--dimensionX', dest='dx', default='dx',
                        help='Used name for the dimensions X of chips')
    parser.add_argument('-y', '--dimensionY', dest='dy', default='dy',
                        help='Used name for the dimensions Y of chips')
    parser.add_argument('-s', '--short', dest='short', action="store_true", default=False,
                        help='Use short version')
    parser.add_argument('-o', '--out', dest='output', type=str, nargs='*',
                        help='Output file')
    args = parser.parse_args()
    files = []

    if args.all:
        files = [f for f in os.listdir('.') if f.endswith(".txt")]
    else:
        files = args.files
    
    for f in files:
        
        input_file = open(f, "r")
        if args.output is not None and len(args.output) == len(files):
            output_file = open(args.output, "w")
        else:
            output_file = open(f[:-3]+"dzn", "w")
        parse_file(input_file, output_file, args.width, args.n, args.dx, args.dy, args.short)
        input_file.close()
        output_file.close()
