import argparse
from colored import bg, attr
import os
os.system("")

def remove_empty_line(out):
    j = len(out[0])-1
    while j >= 0:
        for i in range(len(out)):
            if out[i][j] > 0:
                break
        if i < len(out)-1:
            break
        else:
            for i in range(len(out)):
                out[i].pop()
        j -= 1

def index_to_color(k,n):
        return bg(int((k+1.0)*256/(n+2))) if k >= 0 else bg(0)

def print_nice(width, x, y, dx, dy, space, verbose=False):
    n = len(x)
    hmax = sum([max(dx[i], dy[i]) for i in range(n)])
    out = [[-1 for _ in range(hmax)] for _ in range(width*2)]
    for k in range(n):
        for i in range(dx[k]):
            for j in range(dy[k]):
                if out[x[k]+i][y[k]+j] != -1 and verbose:
                    print(f"ERROR {k}:{x[k]+i},{y[k]+j} already ocupied by {out[x[k]+i][y[k]+j]}")
                out[x[k]+i][y[k]+j] = k
    remove_empty_line(out)
    height = len(out[0])

    for j in range(height-1, -1, -1):
        print("".join([index_to_color(out[i][j], n)+" "*space for i in range(len(out))]) + attr('reset'))
    print("Final height: "+ str(height))

def remove_outofboud(x,y,dx,dy, width, height, verbose=False):
    i=0
    while i < len(x):
        if x[i]+dx[i] > width or y[i] > height:
            if verbose:
                print("removed: ", x[i], y[i], dx[i], dy[i])
            del x[i]
            del y[i]
            del dx[i]
            del dy[i]
            i -= 1
        i += 1
    return (x, y, dx, dy)

def input_set(x, array=False):
    return x is not None and (not array or len(x) > 0)


def main():
    parser = argparse.ArgumentParser(
        description='Print in a nice format')
    parser.add_argument('-x', '--X', dest='x', type=int, nargs='*',
                        help='Position X for chips')
    parser.add_argument('-y', '--Y', dest='y', type=int, nargs='*',
                        help='Position Y for chips')
    parser.add_argument('-dx', '--dimensionx', dest='dx', type=int, nargs='*',
                        help='Dimension on the X axis for each chips')
    parser.add_argument('-dy', '--dimensiony', dest='dy', type=int, nargs='*',
                        help='Dimension on the X axis for each chips')
    parser.add_argument('-d', '--dimension', dest='dim', type=int, nargs='*',
                        help='Dimension on the X and Y axis for each chips (eg. x0, y0, x1, y1, ...)')
    parser.add_argument('-w', '--width', dest='width', type=int,
                        help='Width of the grid to use')
    parser.add_argument('-c', '--coordinates', dest='pos', type=int, nargs='*',
                        help='Coordinates in this format: x0 y0 x1 y1 ...')
    parser.add_argument('-s', '--spaces', dest='space', type=int, default="1",
                        help='Spaces to use for each box')
    parser.add_argument('-v', '--verbose', dest='verbose', action="store_true", default=False,
                        help='Show additional information')
    args = parser.parse_args()

    if input_set(args.pos, array=True):
        x = args.pos[::2]
        y = args.pos[1::2]
    elif input_set(args.x, array=True) and input_set(args.y, array=True):
        x = args.x
        y = args.y
    else:
        print("-c or -x and -y required")
        return

    if input_set(args.dx, array=True) and input_set(args.dy, array=True):
        dx = args.dx
        dy = args.dy
        width = args.width
    elif input_set(args.dim, array=True):
        dx = args.dim[::2]
        dy = args.dim[1::2]
        width = args.width        
    else:
        print("-d or -dx and -dy required")
        return
    max_height = sum([max(dx[i], dy[i]) for i in range(len(dx))])
    (x, y, dx, dy) = remove_outofboud(x, y, dx, dy, width, max_height, args.verbose)
    
    print_nice(width, x, y, dx, dy, args.space, args.verbose)

if __name__ == '__main__':
    main()
